* Choose the nearest diamond.
* Calculate the distance in X and Y.
* Move to the goal.

* If not then release the two rats which avoid obstacles and find the shortest path  to the edge. 
* Not implemented as it should check the falling rocks and butterflies.

upd: 
**A temporary decision before learning to hunt butterflies**

* Planted the butterfly in cages
*If hit the territory of butterflies or ended the goal include a mode of fearlessness

**Rats should be trained better.**

